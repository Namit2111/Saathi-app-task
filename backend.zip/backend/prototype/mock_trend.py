mock_trend = {
    'Mumbai': {
        'trend_restaurant': ['The Table'],
        'trend_activities': ['Beach Visit'],
        'trend_place': ['Marine Drive']
    },
    'Shimla': {
        'trend_restaurant': ['Cafe Simla Times'],
        'trend_activities': ['Skiing'],
        'trend_place': ['Mall Road']
    },
    'Goa': {
        'trend_restaurant': ['Fisherman\'s Wharf'],
        'trend_activities': ['Water Sports'],
        'trend_place': ['Baga Beach']
    },
    'Jaipur': {
        'trend_restaurant': ['Chokhi Dhani'],
        'trend_activities': ['Cultural Experiences'],
        'trend_place': ['Hawa Mahal']
    },
    'Darjeeling': {
        'trend_restaurant': ['Kunga Restaurant'],
        'trend_activities': ['Tea Plantation Visits'],
        'trend_place': ['Tiger Hill']
    },
}
