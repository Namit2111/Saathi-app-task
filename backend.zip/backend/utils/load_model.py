import joblib
import pandas as pd
import os 

BASE_DIR = os.path.dirname(os.path.dirname(__file__))  # This will get you 'backend/'
MODELS_DIR = os.path.join(BASE_DIR, 'models')
def load_model():
    kmeans_model = joblib.load(os.path.join(MODELS_DIR, 'kmeans_model.pkl'))
        
    # Load the OneHotEncoder
    encoder = joblib.load(os.path.join(MODELS_DIR, 'encoder_vibe.pkl'))
    
    # Load the StandardScaler
    scaler = joblib.load(os.path.join(MODELS_DIR, 'scaler.pkl'))
    
    # Load the user dataset with cluster assignments
    df_users = pd.read_csv(os.path.join(MODELS_DIR, 'users.csv'))
    
    print("Models and data successfully loaded.")
    return kmeans_model, encoder, scaler, df_users

if __name__ == '__main__':
    load_model()