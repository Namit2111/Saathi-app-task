import os 
from dotenv import load_dotenv

load_dotenv()

GEMINI_API = os.getenv("GEMINI_API")