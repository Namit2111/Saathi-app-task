# backend/app/routes/__init__.py
# from fastapi import APIRouter
# from . import recommendation

# # Create a main router
# router = APIRouter()

# # Include all route modules
# router.include_router(recommendation.router, prefix="/recommendations", tags=["Recommendations"])
